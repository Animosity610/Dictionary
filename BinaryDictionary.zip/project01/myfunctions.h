#ifndef MY_FUNCTIONS
#define MY_FUNCTIONS
#include<string>
#include<vector>

int binSearch(std::vector<std::string>, std::string, int, int&);
int prefixBinSearch(std::vector <std::string>, std::string, int , int &);
void firstIndex(std::vector<std::string>, std::string, int , int &, int &, int);


#endif
